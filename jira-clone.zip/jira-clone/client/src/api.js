export const authEvents = new EventTarget()

// ---- session token ----
// Sent as a Bearer header on every request, so login works even where cookies are blocked
// (e.g. when the app runs inside a cross-site iframe preview). "Remember me" → localStorage,
// otherwise sessionStorage (cleared when the browser tab closes).
const TOKEN_KEY = 'jc.token'
let memoryToken = null
const store = (kind) => { try { const s = window[kind]; const k = '__jc_test'; s.setItem(k, k); s.removeItem(k); return s } catch { return null } }
export const session = {
  get() {
    return memoryToken || store('sessionStorage')?.getItem(TOKEN_KEY) || store('localStorage')?.getItem(TOKEN_KEY) || null
  },
  set(token, remember = true) {
    memoryToken = token
    store('localStorage')?.removeItem(TOKEN_KEY); store('sessionStorage')?.removeItem(TOKEN_KEY)
    store(remember ? 'localStorage' : 'sessionStorage')?.setItem(TOKEN_KEY, token)
  },
  clear() { memoryToken = null; store('localStorage')?.removeItem(TOKEN_KEY); store('sessionStorage')?.removeItem(TOKEN_KEY) },
  remembered() { return !!store('localStorage')?.getItem(TOKEN_KEY) },
}

// ---- current project + client id (used to ignore our own live-update events) ----
let currentProject = 'KAN'
export const getProject = () => currentProject
export const setProject = (key) => { if (key) currentProject = key }
export const CLIENT_ID = Math.random().toString(36).slice(2, 10)

// Some preview proxies drop the Authorization header and embedded iframes often block cookies. If the
// server says a request arrived with no credentials at all, we fall back to sending the token in the
// query string for the rest of this tab's life.
const TRANSPORT_KEY = 'jc.authTransport'
let queryTransport = (() => { try { return sessionStorage.getItem(TRANSPORT_KEY) === 'query' } catch { return false } })()
const useQueryTransport = () => { queryTransport = true; try { sessionStorage.setItem(TRANSPORT_KEY, 'query') } catch { /* blocked */ } }
const withToken = (url, token) => `${url}${url.includes('?') ? '&' : '?'}access_token=${encodeURIComponent(token)}`
const PUBLIC_AUTH = ['/api/auth/login', '/api/auth/reset', '/api/auth/forgot', '/api/auth/signup', '/api/auth/config', '/api/plans']
export let lastAuthProblem = null

async function send(method, url, body, { raw, headers } = {}, token, viaQuery) {
  let res
  try {
    res = await fetch(token && viaQuery ? withToken(url, token) : url, {
      method,
      credentials: 'include',
      cache: 'no-store',
      headers: {
        ...(raw ? headers : body ? { 'Content-Type': 'application/json' } : {}),
        ...(token ? { Authorization: `Bearer ${token}`, 'X-JC-Auth': token } : {}),
        'X-Client-Id': CLIENT_ID,
      },
      body: raw ? body : body ? JSON.stringify(body) : undefined,
    })
  } catch {
    throw Object.assign(new Error('Can’t reach the server. Check your connection and try again.'), { status: 0, network: true })
  }
  const data = await res.json().catch(() => ({}))
  return { res, data }
}

async function req(method, url, body, opts = {}) {
  const token = session.get()
  let { res, data } = await send(method, url, body, opts, token, queryTransport)
  const isPublic = PUBLIC_AUTH.some((p) => url.startsWith(p))

  if (res.status === 401 && token && !isPublic) {
    // 1) The token never reached the server → retry once with it in the URL.
    if (data.reason === 'no_credentials' && !queryTransport) {
      const retry = await send(method, url, body, opts, token, true)
      if (retry.res.status !== 401) { useQueryTransport(); res = retry.res; data = retry.data }
      else data = retry.data
    }
    // 2) Still 401: only log out if it is our *current* token and the server confirms the session is gone.
    if (res.status === 401) {
      lastAuthProblem = { url, reason: data.reason, seen: data.seen, at: new Date().toISOString() }
      console.warn('[auth] 401', lastAuthProblem)
      if (token === session.get()) {
        let gone = true
        if (url !== '/api/auth/me') {
          const check = await send('GET', '/api/auth/me', null, {}, token, true).catch(() => null)
          gone = !check || check.res.status === 401
          if (!gone) { useQueryTransport(); ({ res, data } = await send(method, url, body, opts, token, true)) }
        }
        if (gone) {
          session.clear()
          if (url !== '/api/auth/me') authEvents.dispatchEvent(new CustomEvent('logout', { detail: { expired: true, reason: data.reason, seen: data.seen } }))
        }
      }
    }
  }
  if (!res.ok) {
    // 402 = the subscription plan doesn't allow this (limit reached or feature locked)
    if (res.status === 402 && data.code === 'plan_limit') authEvents.dispatchEvent(new CustomEvent('plan-limit', { detail: data }))
    throw Object.assign(new Error(data.error || `Request failed (${res.status})`), { status: res.status, reason: data.reason, code: data.code, field: data.field, data })
  }
  return data
}
const q = (params) => {
  const s = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== '')).toString()
  return s ? `?${s}` : ''
}

export const api = {
  // auth & users
  login: async (email, password, remember = true) => {
    const d = await req('POST', '/api/auth/login', { email, password, remember })
    session.set(d.token, remember)
    // Prove the new token actually reaches the server (this also switches to the query-string fallback
    // when a proxy strips headers) before showing the app. Otherwise the user would be let in and then
    // immediately bounced back with "session expired".
    try {
      const me = await req('GET', '/api/auth/me')
      return { ...d, user: me.user || d.user }
    } catch (e) {
      session.clear()
      if (e.status === 401) {
        const seen = lastAuthProblem?.seen ? Object.entries(lastAuthProblem.seen).filter(([, v]) => v).map(([k]) => k).join(', ') || 'nothing' : 'unknown'
        throw Object.assign(new Error(`Logged in, but your browser or network dropped the session on the next request (server received: ${seen}). Try allowing cookies for this site or open the app in a new tab.`), { status: 0 })
      }
      throw e
    }
  },
  // sign-up & social login
  authConfig: () => req('GET', '/api/auth/config'),
  signupStart: (email) => req('POST', '/api/auth/signup/start', { email }),
  signupVerify: (email, code) => req('POST', '/api/auth/signup/verify', { email, code }),
  signupComplete: async (signupToken, name, password, remember = true) => {
    const d = await req('POST', '/api/auth/signup/complete', { signupToken, name, password, remember })
    session.set(d.token, remember)
    const me = await req('GET', '/api/auth/me')
    return { ...d, user: me.user || d.user }
  },
  /** Finishes an OAuth popup sign-in: store the token handed over by the popup and verify it. */
  acceptToken: async (token, remember = true) => {
    session.set(token, remember)
    try { return await req('GET', '/api/auth/me') } catch (e) { session.clear(); throw e }
  },
  oauthStartUrl: (provider, { mode = 'login', popup = true, remember = true } = {}) => `/api/auth/oauth/${provider}/start?mode=${mode}&popup=${popup ? 1 : 0}&remember=${remember ? 1 : 0}`,
  identities: () => req('GET', '/api/auth/identities'),
  unlinkIdentity: (provider) => req('DELETE', `/api/auth/identities/${provider}`),
  adminSite: () => req('GET', '/api/admin/site'),
  saveAdminSite: (fields) => req('PUT', '/api/admin/site', fields),
  authProviders: () => req('GET', '/api/admin/auth-providers'),
  saveAuthProvider: (key, fields) => req('PUT', `/api/admin/auth-providers/${key}`, fields),
  // plans & billing (mock payments)
  plans: () => req('GET', '/api/plans'),
  billing: () => req('GET', '/api/billing'),
  billingQuote: (plan, cycle) => req('GET', `/api/billing/quote?plan=${plan}&cycle=${cycle}`),
  checkout: (fields) => req('POST', '/api/billing/checkout', fields),
  startTrial: (plan = 'premium') => req('POST', '/api/billing/trial', { plan }),
  cancelSubscription: () => req('POST', '/api/billing/cancel'),
  resumeSubscription: () => req('POST', '/api/billing/resume'),
  updateCard: (card) => req('PUT', '/api/billing/payment-method', card),
  saveBillingDetails: (fields) => req('PUT', '/api/billing/details', fields),
  invoices: () => req('GET', '/api/billing/invoices'),
  invoiceHtml: async (id) => {
    const token = session.get()
    const res = await fetch(token ? withToken(`/api/billing/invoices/${id}/html`, token) : `/api/billing/invoices/${id}/html`, { credentials: 'include', headers: token ? { Authorization: `Bearer ${token}` } : {} })
    if (!res.ok) throw new Error('Could not load the invoice.')
    return res.text()
  },
  logout: async () => { try { await req('POST', '/api/auth/logout') } finally { session.clear() } },
  forgotPassword: (email) => req('POST', '/api/auth/forgot', { email }),
  resetInfo: (token) => req('GET', `/api/auth/reset/${encodeURIComponent(token)}`),
  resetPassword: (token, password) => req('POST', '/api/auth/reset', { token, password }),
  sessions: () => req('GET', '/api/auth/sessions'),
  revokeOtherSessions: () => req('DELETE', '/api/auth/sessions'),
  revokeSession: (id) => req('DELETE', `/api/auth/sessions/${id}`),
  me: () => req('GET', '/api/auth/me'),
  updateMe: (fields) => req('PATCH', '/api/auth/me', fields),
  users: () => req('GET', '/api/users'),
  createUser: (fields) => req('POST', '/api/users', fields),
  updateUser: (id, fields) => req('PATCH', `/api/users/${id}`, fields),
  deleteUser: (id) => req('DELETE', `/api/users/${id}`),

  // project & meta
  meta: (project = currentProject) => req('GET', `/api/meta${q({ project })}`),
  updateProject: (fields, key = currentProject) => req('PATCH', `/api/projects/${key}`, fields),
  renameProject: (name, key = currentProject) => req('PATCH', `/api/projects/${key}`, { name }),
  projects: (search) => req('GET', `/api/projects${q({ q: search })}`),
  project: (key) => req('GET', `/api/projects/${key}`),
  createProject: (fields) => req('POST', '/api/projects', fields),
  deleteProject: (key, confirm) => req('DELETE', `/api/projects/${key}`, { confirm }),
  starProject: (key, on) => req(on ? 'POST' : 'DELETE', `/api/projects/${key}/star`),
  // releases
  versions: (status, project = currentProject) => req('GET', `/api/versions${q({ project, status })}`),
  version: (id) => req('GET', `/api/versions/${id}`),
  createVersion: (fields) => req('POST', '/api/versions', { projectKey: currentProject, ...fields }),
  updateVersion: (id, fields) => req('PATCH', `/api/versions/${id}`, fields),
  releaseVersion: (id, body) => req('POST', `/api/versions/${id}/release`, body),
  deleteVersion: (id, moveTo = null) => req('DELETE', `/api/versions/${id}`, { moveTo }),
  // reports
  velocity: (project = currentProject) => req('GET', `/api/reports/velocity${q({ project })}`),
  cfd: (days = 30, project = currentProject) => req('GET', `/api/reports/cfd${q({ project, days })}`),
  sprintReport: (id) => req('GET', `/api/reports/sprint/${id}`),
  // personal API tokens
  apiTokens: () => req('GET', '/api/auth/tokens'),
  createApiToken: (name, expiresInDays) => req('POST', '/api/auth/tokens', { name, expiresInDays }),
  revokeApiToken: (id) => req('DELETE', `/api/auth/tokens/${id}`),

  // issues
  search: (jql, opts = {}) => req('GET', `/api/search${q({ jql, ...opts })}`),
  issue: (key) => req('GET', `/api/issues/${key}`),
  create: (fields) => req('POST', '/api/issues', fields),
  update: (key, fields) => req('PATCH', `/api/issues/${key}`, fields),
  remove: (key) => req('DELETE', `/api/issues/${key}`),
  clone: (key) => req('POST', `/api/issues/${key}/clone`),
  bulk: (payload) => req('POST', '/api/issues/bulk', payload),
  rank: (key, pos) => req('POST', `/api/issues/${key}/rank`, pos),
  addComment: (key, body) => req('POST', `/api/issues/${key}/comments`, { body }),
  editComment: (id, body) => req('PATCH', `/api/comments/${id}`, { body }),
  deleteComment: (id) => req('DELETE', `/api/comments/${id}`),
  watch: (key) => req('POST', `/api/issues/${key}/watch`),
  unwatch: (key) => req('DELETE', `/api/issues/${key}/watch`),
  addLink: (key, type, targetKey, direction) => req('POST', `/api/issues/${key}/links`, { type, targetKey, direction }),
  removeLink: (id) => req('DELETE', `/api/links/${id}`),
  upload: (key, file) => req('POST', `/api/issues/${key}/attachments`, file, {
    raw: true, headers: { 'Content-Type': file.type || 'application/octet-stream', 'X-Filename': encodeURIComponent(file.name) },
  }),
  deleteAttachment: (id) => req('DELETE', `/api/attachments/${id}`),
  // ---- phase 7: time tracking, votes, preferences, automation, webhooks, import ----
  worklogs: (key) => req('GET', `/api/issues/${key}/worklogs`),
  logWork: (key, fields) => req('POST', `/api/issues/${key}/worklogs`, fields),
  updateWorklog: (id, fields) => req('PATCH', `/api/worklogs/${id}`, fields),
  deleteWorklog: (id, adjustEstimate = 'auto') => req('DELETE', `/api/worklogs/${id}?adjustEstimate=${adjustEstimate}`),
  timesheet: (project, from, to, user) => req('GET', `/api/reports/timesheet?project=${project}&from=${from}&to=${to}${user ? `&user=${user}` : ''}`),
  vote: (key) => req('POST', `/api/issues/${key}/votes`),
  unvote: (key) => req('DELETE', `/api/issues/${key}/votes`),
  voters: (key) => req('GET', `/api/issues/${key}/votes`),
  preferences: () => req('GET', '/api/auth/me/preferences'),
  savePreferences: (fields) => req('PATCH', '/api/auth/me/preferences', fields),
  uploadAvatar: (file) => req('POST', '/api/auth/me/avatar', file, { raw: true, headers: { 'Content-Type': file.type || 'application/octet-stream' } }),
  deleteAvatar: () => req('DELETE', '/api/auth/me/avatar'),
  automation: (project) => req('GET', `/api/projects/${project}/automation`),
  createRule: (project, fields) => req('POST', `/api/projects/${project}/automation`, fields),
  updateRule: (id, fields) => req('PATCH', `/api/automation/${id}`, fields),
  deleteRule: (id) => req('DELETE', `/api/automation/${id}`),
  ruleRuns: (id) => req('GET', `/api/automation/${id}/runs`),
  runRule: (id, issueKey) => req('POST', `/api/automation/${id}/run`, { issueKey }),
  automationAudit: (project, status) => req('GET', `/api/projects/${project}/automation/audit?limit=100${status ? `&status=${status}` : ''}`),
  webhooks: () => req('GET', '/api/admin/webhooks'),
  createWebhook: (fields) => req('POST', '/api/admin/webhooks', fields),
  updateWebhook: (id, fields) => req('PATCH', `/api/admin/webhooks/${id}`, fields),
  deleteWebhook: (id) => req('DELETE', `/api/admin/webhooks/${id}`),
  testWebhook: (id) => req('POST', `/api/admin/webhooks/${id}/test`),
  webhookDeliveries: (id) => req('GET', `/api/admin/webhooks/${id}/deliveries`),
  webhookDelivery: (id) => req('GET', `/api/admin/webhook-deliveries/${id}`),
  redeliver: (id) => req('POST', `/api/admin/webhook-deliveries/${id}/redeliver`),
  importCsv: (project, csv, dryRun) => req('POST', `/api/projects/${project}/import`, { csv, dryRun }),
  attachmentUrl: (id, inline) => {
    const p = new URLSearchParams()
    if (inline) p.set('inline', '1')
    const t = session.get(); if (t) p.set('access_token', t) // <img>/<a download> cannot send headers
    const qs = p.toString()
    return `/api/attachments/${id}${qs ? `?${qs}` : ''}`
  },
  addDev: (key, item) => req('POST', `/api/issues/${key}/dev`, item),

  // workspace
  quicksearch: (text) => req('GET', `/api/quicksearch${q({ q: text })}`),
  activity: (limit = 30, project = currentProject) => req('GET', `/api/activity${q({ limit, project })}`),
  workedOn: () => req('GET', '/api/me/worked-on'),
  notifications: () => req('GET', '/api/notifications'),
  markRead: (ids) => req('POST', '/api/notifications/read', ids ? { ids } : {}),
  filters: () => req('GET', '/api/filters'),
  createFilter: (fields) => req('POST', '/api/filters', fields),
  updateFilter: (id, fields) => req('PATCH', `/api/filters/${id}`, fields),
  deleteFilter: (id) => req('DELETE', `/api/filters/${id}`),
  goals: () => req('GET', '/api/goals'),
  goal: (id) => req('GET', `/api/goals/${id}`),
  createGoal: (fields) => req('POST', '/api/goals', fields),
  updateGoal: (id, fields) => req('PATCH', `/api/goals/${id}`, fields),
  deleteGoal: (id) => req('DELETE', `/api/goals/${id}`),
  linkGoalIssue: (id, key) => req('POST', `/api/goals/${id}/issues`, { key }),
  unlinkGoalIssue: (id, key) => req('DELETE', `/api/goals/${id}/issues/${key}`),
  sprints: (state, project = currentProject) => req('GET', `/api/sprints${q({ state, project })}`),
  createSprint: (fields = {}) => req('POST', '/api/sprints', { projectKey: currentProject, ...fields }),
  updateSprint: (id, fields) => req('PATCH', `/api/sprints/${id}`, fields),
  startSprint: (id, fields) => req('POST', `/api/sprints/${id}/start`, fields),
  completeSprint: (id, moveTo) => req('POST', `/api/sprints/${id}/complete`, { moveTo }),
  deleteSprint: (id) => req('DELETE', `/api/sprints/${id}`),
  moveToSprint: (keys, sprintId) => req('POST', '/api/sprints/move', { keys, sprintId }),
  forms: (project = currentProject) => req('GET', `/api/forms${q({ project })}`),
  createForm: (fields) => req('POST', '/api/forms', { projectKey: currentProject, ...fields }),
  updateForm: (id, fields) => req('PATCH', `/api/forms/${id}`, fields),
  deleteForm: (id) => req('DELETE', `/api/forms/${id}`),
  submitForm: (id, values) => req('POST', `/api/forms/${id}/submit`, { values }),
  dev: (params = {}) => req('GET', `/api/dev${q(params)}`),
  updateDev: (id, fields) => req('PATCH', `/api/dev/${id}`, fields),
  deleteDev: (id) => req('DELETE', `/api/dev/${id}`),
  // phase 5: people & roles, permissions, board, components, recycle bin, audit, teams
  members: (key = currentProject) => req('GET', `/api/projects/${key}/members`),
  addMember: (userId, role, key = currentProject) => req('POST', `/api/projects/${key}/members`, { userId, role }),
  setMemberRole: (userId, role, key = currentProject) => req('PATCH', `/api/projects/${key}/members/${userId}`, { role }),
  removeMember: (userId, key = currentProject) => req('DELETE', `/api/projects/${key}/members/${userId}`),
  permissionScheme: (key = currentProject) => req('GET', `/api/projects/${key}/permissions`),
  savePermissionScheme: (scheme, key = currentProject) => req('PUT', `/api/projects/${key}/permissions`, { scheme }),
  resetPermissionScheme: (key = currentProject) => req('POST', `/api/projects/${key}/permissions/reset`),
  myPermissions: (project = currentProject) => req('GET', `/api/mypermissions${q({ project })}`),
  globalPermissions: () => req('GET', '/api/permissions/global'),
  saveGlobalPermissions: (scheme) => req('PUT', '/api/permissions/global', { scheme }),
  updateBoard: (fields, key = currentProject) => req('PATCH', `/api/projects/${key}/board`, fields),
  components: (project = currentProject) => req('GET', `/api/components${q({ project })}`),
  createComponent: (fields) => req('POST', '/api/components', { project: currentProject, ...fields }),
  updateComponent: (id, fields) => req('PATCH', `/api/components/${id}`, fields),
  deleteComponent: (id, moveTo = null) => req('DELETE', `/api/components/${id}`, { moveTo }),
  trash: (project = currentProject) => req('GET', `/api/trash${q({ project })}`),
  restoreTrash: (id) => req('POST', `/api/trash/${id}/restore`),
  purgeTrash: (id) => req('DELETE', `/api/trash/${id}`),
  audit: (params = {}) => req('GET', `/api/audit${q(params)}`),
  teams: () => req('GET', '/api/teams'),
  team: (id) => req('GET', `/api/teams/${id}`),
  createTeam: (fields) => req('POST', '/api/teams', fields),
  updateTeam: (id, fields) => req('PATCH', `/api/teams/${id}`, fields),
  deleteTeam: (id) => req('DELETE', `/api/teams/${id}`),
  reset: async () => { const d = await req('POST', '/api/reset'); if (d.token) session.set(d.token, session.remembered()); return d },
}

// ---- recently viewed work items (client-side, per browser) ----
export const recent = {
  get: () => { try { return JSON.parse(localStorage.getItem('jc.recent') || '[]') } catch { return [] } },
  push: (issue) => {
    const list = recent.get().filter((x) => x.key !== issue.key)
    list.unshift({ key: issue.key, summary: issue.summary, type: issue.type, viewed: new Date().toISOString() })
    localStorage.setItem('jc.recent', JSON.stringify(list.slice(0, 20)))
    window.dispatchEvent(new Event('jc-recent'))
  },
  clear: () => { localStorage.removeItem('jc.recent'); window.dispatchEvent(new Event('jc-recent')) },
  remove: (key) => { localStorage.setItem('jc.recent', JSON.stringify(recent.get().filter((x) => x.key !== key))); window.dispatchEvent(new Event('jc-recent')) },
}

// ---- live updates (Server-Sent Events) ----
// EventSource cannot send headers, so the session token goes in the query string (accepted only for /api/events).
export function connectEvents({ onChange, onPresence } = {}) {
  let es = null; let stopped = false; let timer = null
  const open = () => {
    if (stopped || typeof EventSource === 'undefined') return
    const token = session.get()
    es = new EventSource(`/api/events${q({ access_token: token, client: CLIENT_ID })}`, { withCredentials: true })
    es.addEventListener('change', (e) => { try { const d = JSON.parse(e.data); if (d.client !== CLIENT_ID) onChange?.(d) } catch { /* ignore */ } })
    const pres = (e) => { try { onPresence?.(JSON.parse(e.data).users || []) } catch { /* ignore */ } }
    es.addEventListener('presence', pres); es.addEventListener('hello', pres)
    es.onerror = () => { es.close(); if (!stopped) timer = setTimeout(open, 5000) }
  }
  open()
  return () => { stopped = true; clearTimeout(timer); es?.close() }
}
